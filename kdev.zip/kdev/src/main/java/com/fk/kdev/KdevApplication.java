package com.fk.kdev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KdevApplication {

	public static void main(String[] args) {
		SpringApplication.run(KdevApplication.class, args);
	}

}
